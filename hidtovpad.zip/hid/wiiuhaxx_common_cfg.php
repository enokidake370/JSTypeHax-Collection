<?php

$wiiuhaxxcfg_payloadfilepath = "code550.bin";
$wiiuhaxxcfg_searchpayloadfilepath = "wiiuhaxx_common/wiiuhaxx_searcher.bin";

?>