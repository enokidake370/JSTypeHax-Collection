<a style="font-size: 40px;" href="index-hax.php">HAXX</a><br>

It's important to start the exploit by clicking on a link, visting the exploit site directly probably will crash. <br>
<b> Make sure to have a valid "payload.elf" on your sd card. </b>